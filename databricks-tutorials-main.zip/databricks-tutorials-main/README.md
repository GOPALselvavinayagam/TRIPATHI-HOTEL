# databricks-tutorials
This repo holds the content from my databricks free edition youtube playlist.

[Databricks Free Edition Playlist](https://youtube.com/playlist?list=PLz-qytj7eIWWRz_1hFSleVBwZAoD1eTqU&si=5UoRRMVlG78UR7Nv)
